## Survellience Watcher

* Underlying survellience and data extraction happen with every single click.
* Download the extension to be **alerted** every time you try to visit a link.

![GitHub Logo](screenshot.png)
